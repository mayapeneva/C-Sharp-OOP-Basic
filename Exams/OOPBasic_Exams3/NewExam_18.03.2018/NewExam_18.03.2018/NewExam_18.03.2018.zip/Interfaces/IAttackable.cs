﻿public interface IAttackable
{
    void Attack(Character character);
}