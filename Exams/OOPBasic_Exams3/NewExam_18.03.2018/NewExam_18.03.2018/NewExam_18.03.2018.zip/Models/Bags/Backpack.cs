﻿public class Backpack : Bag
{
}